import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api, LiveSession, StreamingToken } from '@/lib/api';
import { useAuth } from '@/contexts/AuthContext';
import { useAgoraRTC } from '@/hooks/useAgoraRTC';
import { LiveChat } from '@/components/live/LiveChat';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Radio, Users, Mic, MicOff, Camera, CameraOff, PhoneOff, ScreenShare } from 'lucide-react';
import { toast } from 'sonner';

export default function InstructorLiveStudio() {
    const { sessionId } = useParams<{ sessionId: string }>();
    const navigate = useNavigate();
    const { user } = useAuth();
    const [session, setSession] = useState<LiveSession | null>(null);
    const [streamingToken, setStreamingToken] = useState<StreamingToken | null>(null);
    const [loading, setLoading] = useState(true);
    const [elapsedTime, setElapsedTime] = useState(0);
    const localVideoRef = useRef<HTMLDivElement>(null);

    // Agora hook - always called, but only connects when enabled (has token)
    const agoraState = useAgoraRTC({
        appId: streamingToken?.app_id || '',
        channel: streamingToken?.channel_name || '',
        token: streamingToken?.token || '',
        uid: streamingToken?.uid || 0,
        role: 'publisher',
        enabled: !!streamingToken, // Only connect when we have a token
    });

    useEffect(() => {
        loadSession();
    }, [sessionId]);

    // Timer
    useEffect(() => {
        if (session?.status === 'live') {
            const interval = setInterval(() => {
                setElapsedTime((prev) => prev + 1);
            }, 1000);
            return () => clearInterval(interval);
        }
    }, [session?.status]);

    // Attach local video
    useEffect(() => {
        if (agoraState?.localVideoTrack && localVideoRef.current) {
            agoraState.localVideoTrack.play(localVideoRef.current);
        }
    }, [agoraState?.localVideoTrack]);

    const loadSession = async () => {
        if (!sessionId) return;
        try {
            setLoading(true);
            // Get session details - need to use instructor endpoint
            const sessionsData = await api.getInstructorLiveSessions();
            const sessionData = sessionsData.find((s) => s.id === parseInt(sessionId));

            if (!sessionData) {
                toast.error('Session not found');
                navigate('/instructor/dashboard');
                return;
            }

            setSession(sessionData);

            if (sessionData.status === 'live') {
                const token = await api.getStreamingToken(parseInt(sessionId), 'publisher');
                setStreamingToken(token);
            }
        } catch (err: any) {
            console.error('Failed to load session:', err);
            toast.error(err.message || 'Failed to load session');
        } finally {
            setLoading(false);
        }
    };

    const handleEndSession = async () => {
        if (!sessionId) return;
        try {
            await agoraState?.leave();
            await api.endLiveSession(parseInt(sessionId));
            toast.success('Session ended');
            navigate('/instructor/dashboard');
        } catch (err: any) {
            toast.error(err.message || 'Failed to end session');
        }
    };

    const formatTime = (seconds: number) => {
        const hrs = Math.floor(seconds / 3600);
        const mins = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;
        return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    };

    if (loading) {
        return (
            <div className="min-h-screen bg-background flex items-center justify-center">
                <div className="text-center">
                    <Radio className="h-12 w-12 animate-pulse text-primary mx-auto mb-4" />
                    <p>Loading studio...</p>
                </div>
            </div>
        );
    }

    if (!session) {
        return (
            <div className="min-h-screen bg-background flex items-center justify-center">
                <p>Session not found</p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-background">
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b bg-muted/50">
                <div className="flex items-center gap-4">
                    <Button variant="ghost" size="icon" onClick={() => navigate('/instructor/dashboard')}>
                        <ArrowLeft className="h-5 w-5" />
                    </Button>
                    <div>
                        <div className="flex items-center gap-2">
                            <h1 className="font-semibold">{session.title}</h1>
                            {session.status === 'live' && (
                                <Badge className="bg-red-500 animate-pulse">
                                    <Radio className="h-3 w-3 mr-1" />
                                    LIVE
                                </Badge>
                            )}
                        </div>
                        <p className="text-sm text-muted-foreground">Live Studio</p>
                    </div>
                </div>
                <div className="flex items-center gap-4">
                    <Badge variant="outline" className="gap-1 text-lg px-4 py-1">
                        {formatTime(elapsedTime)}
                    </Badge>
                    <Badge variant="outline" className="gap-1">
                        <Users className="h-3 w-3" />
                        {session.current_participants} watching
                    </Badge>
                </div>
            </div>

            {/* Main Content */}
            <div className="flex h-[calc(100vh-73px)]">
                {/* Video Preview & Controls */}
                <div className="flex-1 flex flex-col">
                    {/* Video Preview */}
                    <div className="flex-1 bg-black relative">
                        <div
                            ref={localVideoRef}
                            className="w-full h-full flex items-center justify-center"
                        >
                            {!agoraState?.isPublishing && (
                                <div className="text-center text-white">
                                    <Camera className="h-16 w-16 mx-auto mb-4 opacity-50" />
                                    <p>Camera preview will appear here</p>
                                </div>
                            )}
                        </div>

                        {/* Connection Status */}
                        <div className="absolute top-4 right-4">
                            {agoraState?.isConnected ? (
                                <Badge className="bg-green-500">Connected</Badge>
                            ) : (
                                <Badge variant="destructive">Connecting...</Badge>
                            )}
                        </div>
                    </div>

                    {/* Controls */}
                    <div className="p-6 bg-muted/50 border-t">
                        <div className="flex items-center justify-center gap-4">
                            <Button
                                variant={agoraState?.isMuted ? 'destructive' : 'outline'}
                                size="lg"
                                onClick={() => agoraState?.toggleMute()}
                                className="gap-2"
                            >
                                {agoraState?.isMuted ? (
                                    <MicOff className="h-5 w-5" />
                                ) : (
                                    <Mic className="h-5 w-5" />
                                )}
                                {agoraState?.isMuted ? 'Unmute' : 'Mute'}
                            </Button>

                            <Button
                                variant={agoraState?.isVideoOff ? 'destructive' : 'outline'}
                                size="lg"
                                onClick={() => agoraState?.toggleVideo()}
                                className="gap-2"
                            >
                                {agoraState?.isVideoOff ? (
                                    <CameraOff className="h-5 w-5" />
                                ) : (
                                    <Camera className="h-5 w-5" />
                                )}
                                {agoraState?.isVideoOff ? 'Start Video' : 'Stop Video'}
                            </Button>

                            <Button
                                variant="destructive"
                                size="lg"
                                onClick={handleEndSession}
                                className="gap-2"
                            >
                                <PhoneOff className="h-5 w-5" />
                                End Session
                            </Button>
                        </div>
                    </div>
                </div>

                {/* Chat Sidebar */}
                <div className="w-80 border-l flex flex-col">
                    <div className="flex-1">
                        {user && (
                            <LiveChat
                                sessionId={parseInt(sessionId!)}
                                userId={user.id}
                                username={user.name}
                                isInstructor
                                instructorId={user.id}
                            />
                        )}
                    </div>

                    {/* Session Stats */}
                    <Card className="m-4">
                        <CardHeader className="pb-2">
                            <CardTitle className="text-sm">Session Stats</CardTitle>
                        </CardHeader>
                        <CardContent className="text-sm space-y-2">
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">Duration</span>
                                <span className="font-medium">{formatTime(elapsedTime)}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">Viewers</span>
                                <span className="font-medium">{session.current_participants}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">Revenue</span>
                                <span className="font-medium text-green-600">
                                    ₹{(session.current_participants || 0) * session.price}
                                </span>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}
