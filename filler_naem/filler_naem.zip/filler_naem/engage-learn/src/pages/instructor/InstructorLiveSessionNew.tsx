import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, LiveSessionCreate } from '@/lib/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Radio, Calendar, Clock, IndianRupee, Users, Tag } from 'lucide-react';
import { toast } from 'sonner';

export default function InstructorLiveSessionNew() {
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false);
    const [formData, setFormData] = useState({
        title: '',
        description: '',
        scheduled_start: '',
        scheduled_end: '',
        price: '',
        max_participants: '',
        category: '',
    });

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!formData.title || !formData.scheduled_start || !formData.scheduled_end) {
            toast.error('Please fill in all required fields');
            return;
        }

        try {
            setLoading(true);
            const sessionData: LiveSessionCreate = {
                title: formData.title,
                description: formData.description || undefined,
                scheduled_start: new Date(formData.scheduled_start).toISOString(),
                scheduled_end: new Date(formData.scheduled_end).toISOString(),
                price: parseFloat(formData.price) || 0,
                max_participants: formData.max_participants ? parseInt(formData.max_participants) : undefined,
                category: formData.category || undefined,
            };

            await api.createLiveSession(sessionData);
            toast.success('Live session scheduled!');
            navigate('/instructor/dashboard');
        } catch (err: any) {
            console.error('Failed to create session:', err);
            toast.error(err.message || 'Failed to create session');
        } finally {
            setLoading(false);
        }
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setFormData((prev) => ({
            ...prev,
            [e.target.name]: e.target.value,
        }));
    };

    return (
        <div className="min-h-screen bg-background p-6">
            <div className="max-w-2xl mx-auto">
                {/* Header */}
                <div className="flex items-center gap-4 mb-6">
                    <Button variant="ghost" size="icon" onClick={() => navigate('/instructor/dashboard')}>
                        <ArrowLeft className="h-5 w-5" />
                    </Button>
                    <div>
                        <h1 className="text-2xl font-bold">Schedule Live Session</h1>
                        <p className="text-muted-foreground">
                            Create a new live streaming session
                        </p>
                    </div>
                </div>

                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Radio className="h-5 w-5 text-red-500" />
                            Session Details
                        </CardTitle>
                        <CardDescription>
                            Fill in the details for your live session
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <form onSubmit={handleSubmit} className="space-y-6">
                            {/* Title */}
                            <div className="space-y-2">
                                <Label htmlFor="title">Title *</Label>
                                <Input
                                    id="title"
                                    name="title"
                                    value={formData.title}
                                    onChange={handleChange}
                                    placeholder="e.g., Introduction to React Hooks"
                                    required
                                />
                            </div>

                            {/* Description */}
                            <div className="space-y-2">
                                <Label htmlFor="description">Description</Label>
                                <Textarea
                                    id="description"
                                    name="description"
                                    value={formData.description}
                                    onChange={handleChange}
                                    placeholder="What will you cover in this session?"
                                    rows={4}
                                />
                            </div>

                            {/* Schedule */}
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="scheduled_start" className="flex items-center gap-2">
                                        <Calendar className="h-4 w-4" />
                                        Start Time *
                                    </Label>
                                    <Input
                                        id="scheduled_start"
                                        name="scheduled_start"
                                        type="datetime-local"
                                        value={formData.scheduled_start}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="scheduled_end" className="flex items-center gap-2">
                                        <Clock className="h-4 w-4" />
                                        End Time *
                                    </Label>
                                    <Input
                                        id="scheduled_end"
                                        name="scheduled_end"
                                        type="datetime-local"
                                        value={formData.scheduled_end}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                            </div>

                            {/* Price & Participants */}
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="price" className="flex items-center gap-2">
                                        <IndianRupee className="h-4 w-4" />
                                        Price (₹)
                                    </Label>
                                    <Input
                                        id="price"
                                        name="price"
                                        type="number"
                                        min="0"
                                        step="0.01"
                                        value={formData.price}
                                        onChange={handleChange}
                                        placeholder="0 for free"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="max_participants" className="flex items-center gap-2">
                                        <Users className="h-4 w-4" />
                                        Max Participants
                                    </Label>
                                    <Input
                                        id="max_participants"
                                        name="max_participants"
                                        type="number"
                                        min="1"
                                        value={formData.max_participants}
                                        onChange={handleChange}
                                        placeholder="Unlimited"
                                    />
                                </div>
                            </div>

                            {/* Category */}
                            <div className="space-y-2">
                                <Label htmlFor="category" className="flex items-center gap-2">
                                    <Tag className="h-4 w-4" />
                                    Category
                                </Label>
                                <Input
                                    id="category"
                                    name="category"
                                    value={formData.category}
                                    onChange={handleChange}
                                    placeholder="e.g., Programming, Design, Marketing"
                                />
                            </div>

                            {/* Submit */}
                            <div className="flex gap-4 pt-4">
                                <Button
                                    type="button"
                                    variant="outline"
                                    onClick={() => navigate('/instructor/live-sessions')}
                                    className="flex-1"
                                >
                                    Cancel
                                </Button>
                                <Button type="submit" disabled={loading} className="flex-1">
                                    {loading ? 'Creating...' : 'Schedule Session'}
                                </Button>
                            </div>
                        </form>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
