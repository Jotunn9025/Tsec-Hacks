import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, LiveSession } from '@/lib/api';
import { useAuth } from '@/contexts/AuthContext';
import { LiveSessionCard } from '@/components/live/LiveSessionCard';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, Plus, Radio, Calendar, History } from 'lucide-react';
import { toast } from 'sonner';

export default function InstructorLiveSessionList() {
    const navigate = useNavigate();
    const { user } = useAuth();
    const [sessions, setSessions] = useState<LiveSession[]>([]);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('upcoming');

    useEffect(() => {
        loadSessions();
    }, []);

    const loadSessions = async () => {
        try {
            setLoading(true);
            const data = await api.getInstructorLiveSessions();
            setSessions(data);
        } catch (err) {
            console.error('Failed to load sessions:', err);
            toast.error('Failed to load sessions');
        } finally {
            setLoading(false);
        }
    };

    const handleStart = async (sessionId: number) => {
        try {
            await api.startLiveSession(sessionId);
            toast.success('Session is now live!');
            navigate(`/instructor/live-studio/${sessionId}`);
        } catch (err: any) {
            toast.error(err.message || 'Failed to start session');
        }
    };

    const handleEnd = async (sessionId: number) => {
        try {
            await api.endLiveSession(sessionId);
            toast.success('Session ended');
            loadSessions();
        } catch (err: any) {
            toast.error(err.message || 'Failed to end session');
        }
    };

    const handleManage = (sessionId: number) => {
        navigate(`/instructor/live-studio/${sessionId}`);
    };

    const upcomingSessions = sessions.filter((s) => s.status === 'scheduled');
    const liveSessions = sessions.filter((s) => s.status === 'live');
    const pastSessions = sessions.filter((s) => s.status === 'ended' || s.status === 'cancelled');

    const getFilteredSessions = () => {
        switch (activeTab) {
            case 'upcoming':
                return upcomingSessions;
            case 'live':
                return liveSessions;
            case 'past':
                return pastSessions;
            default:
                return sessions;
        }
    };

    return (
        <div className="min-h-screen bg-background p-6">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-4">
                        <Button variant="ghost" size="icon" onClick={() => navigate('/instructor/dashboard')}>
                            <ArrowLeft className="h-5 w-5" />
                        </Button>
                        <div>
                            <h1 className="text-2xl font-bold">My Live Sessions</h1>
                            <p className="text-muted-foreground">
                                Manage and stream your live sessions
                            </p>
                        </div>
                    </div>
                    <Button onClick={() => navigate('/instructor/live-sessions/new')} className="gap-2">
                        <Plus className="h-4 w-4" />
                        Schedule Session
                    </Button>
                </div>

                {/* Tabs */}
                <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
                    <TabsList>
                        <TabsTrigger value="upcoming" className="gap-2">
                            <Calendar className="h-3 w-3" />
                            Upcoming ({upcomingSessions.length})
                        </TabsTrigger>
                        <TabsTrigger value="live" className="gap-2">
                            <Radio className="h-3 w-3" />
                            Live ({liveSessions.length})
                        </TabsTrigger>
                        <TabsTrigger value="past" className="gap-2">
                            <History className="h-3 w-3" />
                            Past ({pastSessions.length})
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value={activeTab} className="mt-6">
                        {loading ? (
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                {[1, 2, 3].map((i) => (
                                    <div key={i} className="h-80 bg-muted animate-pulse rounded-lg" />
                                ))}
                            </div>
                        ) : getFilteredSessions().length === 0 ? (
                            <div className="text-center py-12">
                                <Radio className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                                <h3 className="text-lg font-medium">No sessions</h3>
                                <p className="text-muted-foreground mb-4">
                                    {activeTab === 'upcoming'
                                        ? 'Schedule your first live session!'
                                        : activeTab === 'live'
                                            ? 'No live sessions right now.'
                                            : 'No past sessions yet.'}
                                </p>
                                {activeTab === 'upcoming' && (
                                    <Button onClick={() => navigate('/instructor/live-sessions/new')}>
                                        <Plus className="h-4 w-4 mr-2" />
                                        Schedule Session
                                    </Button>
                                )}
                            </div>
                        ) : (
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                {getFilteredSessions().map((session) => (
                                    <LiveSessionCard
                                        key={session.id}
                                        session={session}
                                        isInstructor
                                        onStart={() => handleStart(session.id)}
                                        onEnd={() => handleEnd(session.id)}
                                        onManage={() => handleManage(session.id)}
                                    />
                                ))}
                            </div>
                        )}
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}
