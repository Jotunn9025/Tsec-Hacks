import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api, Course, formatUrl } from '@/lib/api';
import { Navbar } from '@/components/Navbar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Loader2, ImagePlus, X } from 'lucide-react';
import { toast } from 'sonner';

const InstructorCourseEdit = () => {
    const { courseId } = useParams<{ courseId: string }>();
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [formData, setFormData] = useState({
        title: '',
        description: '',
        category: '',
    });
    const [currentImageUrl, setCurrentImageUrl] = useState<string | null>(null);
    const [newImage, setNewImage] = useState<File | null>(null);
    const [imagePreview, setImagePreview] = useState<string | null>(null);

    useEffect(() => {
        const fetchCourse = async () => {
            if (!courseId) return;

            try {
                const course = await api.getInstructorCourse(parseInt(courseId));
                setFormData({
                    title: course.title,
                    description: course.description,
                    category: course.category || '',
                });
                setCurrentImageUrl(course.image_url || null);
            } catch (error) {
                console.error('Failed to fetch course:', error);
                toast.error('Failed to load course');
                navigate('/instructor/dashboard');
            } finally {
                setLoading(false);
            }
        };

        fetchCourse();
    }, [courseId, navigate]);

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            setNewImage(file);
            // Create preview URL
            const previewUrl = URL.createObjectURL(file);
            setImagePreview(previewUrl);
        }
    };

    const removeNewImage = () => {
        setNewImage(null);
        if (imagePreview) {
            URL.revokeObjectURL(imagePreview);
            setImagePreview(null);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!courseId) return;

        setSaving(true);

        try {
            // Always use FormData since backend expects Form parameters
            const formDataToSend = new FormData();
            formDataToSend.append('title', formData.title);
            formDataToSend.append('description', formData.description);
            formDataToSend.append('category', formData.category);

            // Add image only if a new one was selected
            if (newImage) {
                formDataToSend.append('image', newImage);
            }

            const token = localStorage.getItem('access_token');
            const response = await fetch(`https://sequestrable-elsie-knurliest.ngrok-free.dev/instructor/courses/${courseId}`, {
                method: 'PUT',
                headers: {
                    'Authorization': token ? `Bearer ${token}` : '',
                    'ngrok-skip-browser-warning': 'true',
                },
                body: formDataToSend,
            });

            if (!response.ok) {
                throw new Error('Failed to update course');
            }

            toast.success('Course updated successfully!');
            navigate(`/instructor/courses/${courseId}`);
        } catch (error) {
            console.error('Failed to update course:', error);
            toast.error('Failed to update course');
        } finally {
            setSaving(false);
        }
    };

    if (loading) {
        return (
            <div className="min-h-screen bg-background">
                <Navbar />
                <div className="container py-20 text-center">
                    <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
                    <p className="text-muted-foreground">Loading course...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-background">
            <Navbar />

            <section className="container py-8 max-w-2xl">
                <Button
                    variant="ghost"
                    onClick={() => navigate(`/instructor/courses/${courseId}`)}
                    className="mb-6 gap-2"
                >
                    <ArrowLeft className="h-4 w-4" />
                    Back to Course
                </Button>

                <Card>
                    <CardHeader>
                        <CardTitle className="text-2xl">Edit Course</CardTitle>
                        <CardDescription>
                            Update your course information
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div className="space-y-2">
                                <Label htmlFor="title">Course Title *</Label>
                                <Input
                                    id="title"
                                    placeholder="e.g., Introduction to Python"
                                    value={formData.title}
                                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                                    required
                                />
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="description">Description *</Label>
                                <Textarea
                                    id="description"
                                    placeholder="Describe your course..."
                                    value={formData.description}
                                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                    rows={6}
                                    required
                                />
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="category">Category</Label>
                                <Input
                                    id="category"
                                    placeholder="e.g., Programming, Design, Business"
                                    value={formData.category}
                                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                                />
                            </div>

                            {/* Course Image Section */}
                            <div className="space-y-2">
                                <Label>Course Image</Label>

                                {/* Current or New Image Preview */}
                                {(imagePreview || currentImageUrl) && (
                                    <div className="relative w-full aspect-video rounded-lg overflow-hidden border bg-muted mb-2">
                                        <img
                                            src={imagePreview || formatUrl(currentImageUrl!)}
                                            alt="Course preview"
                                            className="w-full h-full object-cover"
                                        />
                                        {imagePreview && (
                                            <Button
                                                type="button"
                                                variant="destructive"
                                                size="icon"
                                                className="absolute top-2 right-2"
                                                onClick={removeNewImage}
                                            >
                                                <X className="h-4 w-4" />
                                            </Button>
                                        )}
                                    </div>
                                )}

                                <div className="flex items-center gap-3">
                                    <Input
                                        id="image"
                                        type="file"
                                        accept="image/*"
                                        onChange={handleImageChange}
                                        className="hidden"
                                    />
                                    <Button
                                        type="button"
                                        variant="outline"
                                        onClick={() => document.getElementById('image')?.click()}
                                        className="gap-2"
                                    >
                                        <ImagePlus className="h-4 w-4" />
                                        {currentImageUrl || imagePreview ? 'Change Image' : 'Upload Image'}
                                    </Button>
                                    {newImage && (
                                        <span className="text-sm text-muted-foreground">
                                            {newImage.name}
                                        </span>
                                    )}
                                </div>
                            </div>

                            <div className="flex gap-3 pt-4">
                                <Button type="submit" disabled={saving} className="flex-1">
                                    {saving ? (
                                        <>
                                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                            Saving...
                                        </>
                                    ) : (
                                        'Save Changes'
                                    )}
                                </Button>
                                <Button
                                    type="button"
                                    variant="outline"
                                    onClick={() => navigate(`/instructor/courses/${courseId}`)}
                                    disabled={saving}
                                >
                                    Cancel
                                </Button>
                            </div>
                        </form>
                    </CardContent>
                </Card>
            </section>
        </div>
    );
};

export default InstructorCourseEdit;
