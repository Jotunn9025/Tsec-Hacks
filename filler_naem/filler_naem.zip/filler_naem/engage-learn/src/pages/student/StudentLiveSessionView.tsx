import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api, LiveSession, StreamingToken } from '@/lib/api';
import { useAuth } from '@/contexts/AuthContext';
import { useAgoraRTC } from '@/hooks/useAgoraRTC';
import { LiveChat } from '@/components/live/LiveChat';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Radio, Users, Maximize, Minimize, Camera, CameraOff, Mic, MicOff } from 'lucide-react';
import { toast } from 'sonner';

export default function StudentLiveSessionView() {
    const { sessionId } = useParams<{ sessionId: string }>();
    const navigate = useNavigate();
    const { user } = useAuth();
    const [session, setSession] = useState<LiveSession | null>(null);
    const [streamingToken, setStreamingToken] = useState<StreamingToken | null>(null);
    const [loading, setLoading] = useState(true);
    const [isFullscreen, setIsFullscreen] = useState(false);
    const videoContainerRef = useRef<HTMLDivElement>(null);

    // Agora hook - always called, but only connects when enabled (has token)
    const agoraState = useAgoraRTC({
        appId: streamingToken?.app_id || '',
        channel: streamingToken?.channel_name || '',
        token: streamingToken?.token || '',
        uid: streamingToken?.uid || 0,
        role: 'subscriber',
        enabled: !!streamingToken, // Only connect when we have a token
    });

    useEffect(() => {
        loadSession();
    }, [sessionId]);

    const loadSession = async () => {
        if (!sessionId) return;
        try {
            setLoading(true);
            const sessionData = await api.getLiveSessionDetails(parseInt(sessionId));
            setSession(sessionData);

            if (sessionData.status === 'live') {
                const token = await api.getStreamingToken(parseInt(sessionId), 'subscriber');
                setStreamingToken(token);
            }
        } catch (err: any) {
            console.error('Failed to load session:', err);
            toast.error(err.message || 'Failed to load session');
            navigate('/student/dashboard');
        } finally {
            setLoading(false);
        }
    };

    const toggleFullscreen = () => {
        if (!document.fullscreenElement) {
            videoContainerRef.current?.requestFullscreen();
            setIsFullscreen(true);
        } else {
            document.exitFullscreen();
            setIsFullscreen(false);
        }
    };

    // Attach remote video when available
    useEffect(() => {
        if (agoraState?.remoteUsers.length && videoContainerRef.current) {
            const remoteUser = agoraState.remoteUsers[0];
            if (remoteUser.videoTrack) {
                remoteUser.videoTrack.play(videoContainerRef.current);
            }
        }
    }, [agoraState?.remoteUsers]);

    if (loading) {
        return (
            <div className="min-h-screen bg-background flex items-center justify-center">
                <div className="text-center">
                    <Radio className="h-12 w-12 animate-pulse text-primary mx-auto mb-4" />
                    <p>Loading live session...</p>
                </div>
            </div>
        );
    }

    if (!session) {
        return (
            <div className="min-h-screen bg-background flex items-center justify-center">
                <div className="text-center">
                    <p>Session not found</p>
                    <Button onClick={() => navigate('/student/dashboard')} className="mt-4">
                        Back to Sessions
                    </Button>
                </div>
            </div>
        );
    }

    if (session.status !== 'live') {
        return (
            <div className="min-h-screen bg-background flex items-center justify-center">
                <div className="text-center">
                    <Radio className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h2 className="text-xl font-semibold mb-2">Session Not Live</h2>
                    <p className="text-muted-foreground mb-4">
                        This session is {session.status}. Please check back later.
                    </p>
                    <Button onClick={() => navigate('/student/dashboard')}>
                        Browse Sessions
                    </Button>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-background">
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b">
                <div className="flex items-center gap-4">
                    <Button variant="ghost" size="icon" onClick={() => navigate('/student/dashboard')}>
                        <ArrowLeft className="h-5 w-5" />
                    </Button>
                    <div>
                        <div className="flex items-center gap-2">
                            <h1 className="font-semibold">{session.title}</h1>
                            <Badge className="bg-red-500 animate-pulse">
                                <Radio className="h-3 w-3 mr-1" />
                                LIVE
                            </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                            by {session.instructor_name}
                        </p>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    <Badge variant="outline" className="gap-1">
                        <Users className="h-3 w-3" />
                        {session.current_participants} watching
                    </Badge>
                </div>
            </div>

            {/* Main Content */}
            <div className="flex h-[calc(100vh-73px)]">
                {/* Video Player */}
                <div className="flex-1 relative bg-black">
                    <div
                        ref={videoContainerRef}
                        className="w-full h-full flex items-center justify-center"
                    >
                        {!agoraState?.remoteUsers.length && (
                            <div className="text-center text-white">
                                <Radio className="h-16 w-16 animate-pulse mx-auto mb-4" />
                                <p>Connecting to stream...</p>
                                {agoraState?.error && (
                                    <p className="text-red-400 mt-2">{agoraState.error.message}</p>
                                )}
                            </div>
                        )}
                    </div>

                    {/* Video Controls */}
                    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-black/50 px-4 py-2 rounded-full">
                        <Button
                            variant="ghost"
                            size="icon"
                            onClick={toggleFullscreen}
                            className="text-white hover:bg-white/20"
                        >
                            {isFullscreen ? (
                                <Minimize className="h-5 w-5" />
                            ) : (
                                <Maximize className="h-5 w-5" />
                            )}
                        </Button>
                    </div>

                    {/* Connection Status */}
                    <div className="absolute top-4 right-4">
                        {agoraState?.isConnected ? (
                            <Badge className="bg-green-500">Connected</Badge>
                        ) : (
                            <Badge variant="destructive">Connecting...</Badge>
                        )}
                    </div>
                </div>

                {/* Chat Sidebar */}
                <div className="w-80 border-l">
                    {user && (
                        <LiveChat
                            sessionId={parseInt(sessionId!)}
                            userId={user.id}
                            username={user.name}
                            instructorId={session.instructor_id}
                        />
                    )}
                </div>
            </div>
        </div>
    );
}
