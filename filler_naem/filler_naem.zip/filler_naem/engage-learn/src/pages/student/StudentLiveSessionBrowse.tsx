import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, LiveSession, SessionRegistration } from '@/lib/api';
import { useAuth } from '@/contexts/AuthContext';
import { LiveSessionCard } from '@/components/live/LiveSessionCard';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { ArrowLeft, Search, Radio, Calendar, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

export default function StudentLiveSessionBrowse() {
    const navigate = useNavigate();
    const { user } = useAuth();
    const [sessions, setSessions] = useState<LiveSession[]>([]);
    const [registrations, setRegistrations] = useState<SessionRegistration[]>([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [activeTab, setActiveTab] = useState('all');

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            setLoading(true);
            const [sessionsData, registrationsData] = await Promise.all([
                api.browseLiveSessions(),
                api.getMyLiveSessionRegistrations(),
            ]);
            setSessions(sessionsData);
            setRegistrations(registrationsData);
        } catch (err) {
            console.error('Failed to load live sessions:', err);
            toast.error('Failed to load live sessions');
        } finally {
            setLoading(false);
        }
    };

    const handleRegister = async (sessionId: number) => {
        try {
            await api.registerForLiveSession(sessionId);
            toast.success('Successfully registered!');
            loadData();
        } catch (err: any) {
            console.error('Failed to register:', err);
            toast.error(err.message || 'Failed to register');
        }
    };

    const handleJoin = async (sessionId: number) => {
        try {
            await api.joinLiveSession(sessionId);
            navigate(`/student/live/${sessionId}`);
        } catch (err: any) {
            console.error('Failed to join:', err);
            toast.error(err.message || 'Failed to join session');
        }
    };

    const isRegistered = (sessionId: number) => {
        return registrations.some((r) => r.session_id === sessionId);
    };

    const filteredSessions = sessions.filter((session) => {
        const matchesSearch =
            session.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
            session.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
            session.category?.toLowerCase().includes(searchQuery.toLowerCase());

        if (activeTab === 'all') return matchesSearch;
        if (activeTab === 'live') return matchesSearch && session.status === 'live';
        if (activeTab === 'scheduled') return matchesSearch && session.status === 'scheduled';
        if (activeTab === 'registered')
            return matchesSearch && isRegistered(session.id);
        return matchesSearch;
    });

    const liveSessions = sessions.filter((s) => s.status === 'live');
    const scheduledSessions = sessions.filter((s) => s.status === 'scheduled');

    return (
        <div className="min-h-screen bg-background p-6">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="flex items-center gap-4 mb-6">
                    <Button variant="ghost" size="icon" onClick={() => navigate('/student/dashboard')}>
                        <ArrowLeft className="h-5 w-5" />
                    </Button>
                    <div>
                        <h1 className="text-2xl font-bold">Live Sessions</h1>
                        <p className="text-muted-foreground">
                            Join live sessions with your favorite instructors
                        </p>
                    </div>
                </div>

                {/* Search */}
                <div className="relative mb-6">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                        placeholder="Search sessions..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10"
                    />
                </div>

                {/* Tabs */}
                <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
                    <TabsList>
                        <TabsTrigger value="all" className="gap-2">
                            All ({sessions.length})
                        </TabsTrigger>
                        <TabsTrigger value="live" className="gap-2">
                            <Radio className="h-3 w-3" />
                            Live ({liveSessions.length})
                        </TabsTrigger>
                        <TabsTrigger value="scheduled" className="gap-2">
                            <Calendar className="h-3 w-3" />
                            Upcoming ({scheduledSessions.length})
                        </TabsTrigger>
                        <TabsTrigger value="registered" className="gap-2">
                            <CheckCircle className="h-3 w-3" />
                            My Sessions ({registrations.length})
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value={activeTab} className="mt-6">
                        {loading ? (
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                {[1, 2, 3].map((i) => (
                                    <div
                                        key={i}
                                        className="h-80 bg-muted animate-pulse rounded-lg"
                                    />
                                ))}
                            </div>
                        ) : filteredSessions.length === 0 ? (
                            <div className="text-center py-12">
                                <Radio className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                                <h3 className="text-lg font-medium">No sessions found</h3>
                                <p className="text-muted-foreground">
                                    {activeTab === 'live'
                                        ? 'No live sessions right now. Check back later!'
                                        : activeTab === 'registered'
                                            ? "You haven't registered for any sessions yet."
                                            : 'Try adjusting your search query.'}
                                </p>
                            </div>
                        ) : (
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                {filteredSessions.map((session) => (
                                    <LiveSessionCard
                                        key={session.id}
                                        session={session}
                                        isRegistered={isRegistered(session.id)}
                                        onRegister={() => handleRegister(session.id)}
                                        onJoin={() => handleJoin(session.id)}
                                    />
                                ))}
                            </div>
                        )}
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}
