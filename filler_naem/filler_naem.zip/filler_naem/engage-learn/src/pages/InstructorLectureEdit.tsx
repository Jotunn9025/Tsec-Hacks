import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api, Lecture, formatUrl } from '@/lib/api';
import { Navbar } from '@/components/Navbar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Loader2, Video, X } from 'lucide-react';
import { toast } from 'sonner';

const InstructorLectureEdit = () => {
    const { courseId, lectureId } = useParams<{ courseId: string; lectureId: string }>();
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [formData, setFormData] = useState({
        title: '',
        description: '',
        duration: 0,
        price_per_10_mins: 0,
    });
    const [currentVideoUrl, setCurrentVideoUrl] = useState<string | null>(null);
    const [newVideo, setNewVideo] = useState<File | null>(null);
    const [videoPreview, setVideoPreview] = useState<string | null>(null);

    useEffect(() => {
        const fetchLecture = async () => {
            if (!courseId || !lectureId) return;

            try {
                const lecture = await api.getLecture(parseInt(courseId), parseInt(lectureId));
                setFormData({
                    title: lecture.title,
                    description: lecture.description,
                    duration: lecture.duration,
                    price_per_10_mins: lecture.price_per_10_mins,
                });
                setCurrentVideoUrl(lecture.video_url || null);
            } catch (error) {
                console.error('Failed to fetch lecture:', error);
                toast.error('Failed to load lecture');
                navigate(`/instructor/courses/${courseId}`);
            } finally {
                setLoading(false);
            }
        };

        fetchLecture();
    }, [courseId, lectureId, navigate]);

    const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            setNewVideo(file);
            // Create preview URL
            const previewUrl = URL.createObjectURL(file);
            setVideoPreview(previewUrl);
        }
    };

    const removeNewVideo = () => {
        setNewVideo(null);
        if (videoPreview) {
            URL.revokeObjectURL(videoPreview);
            setVideoPreview(null);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!courseId || !lectureId) return;

        setSaving(true);

        try {
            // Always use FormData since backend expects Form parameters
            const formDataToSend = new FormData();
            formDataToSend.append('title', formData.title);
            formDataToSend.append('description', formData.description);
            formDataToSend.append('duration', formData.duration.toString());
            formDataToSend.append('price_per_10_mins', formData.price_per_10_mins.toString());

            // Add video only if a new one was selected
            if (newVideo) {
                formDataToSend.append('video', newVideo);
            }

            const token = localStorage.getItem('access_token');
            const response = await fetch(`https://sequestrable-elsie-knurliest.ngrok-free.dev/instructor/courses/${courseId}/lectures/${lectureId}`, {
                method: 'PUT',
                headers: {
                    'Authorization': token ? `Bearer ${token}` : '',
                    'ngrok-skip-browser-warning': 'true',
                },
                body: formDataToSend,
            });

            if (!response.ok) {
                throw new Error('Failed to update lecture');
            }

            toast.success('Lecture updated successfully!');
            navigate(`/instructor/courses/${courseId}`);
        } catch (error) {
            console.error('Failed to update lecture:', error);
            toast.error('Failed to update lecture');
        } finally {
            setSaving(false);
        }
    };

    if (loading) {
        return (
            <div className="min-h-screen bg-background">
                <Navbar />
                <div className="container py-20 text-center">
                    <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
                    <p className="text-muted-foreground">Loading lecture...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-background">
            <Navbar />

            <section className="container py-8 max-w-2xl">
                <Button
                    variant="ghost"
                    onClick={() => navigate(`/instructor/courses/${courseId}`)}
                    className="mb-6 gap-2"
                >
                    <ArrowLeft className="h-4 w-4" />
                    Back to Course
                </Button>

                <Card>
                    <CardHeader>
                        <CardTitle className="text-2xl">Edit Lecture</CardTitle>
                        <CardDescription>
                            Update your lecture information
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div className="space-y-2">
                                <Label htmlFor="title">Lecture Title *</Label>
                                <Input
                                    id="title"
                                    placeholder="e.g., Introduction to Variables"
                                    value={formData.title}
                                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                                    required
                                />
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="description">Description *</Label>
                                <Textarea
                                    id="description"
                                    placeholder="Describe what this lecture covers..."
                                    value={formData.description}
                                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                    rows={4}
                                    required
                                />
                            </div>

                            {/* Lecture Video Section */}
                            <div className="space-y-2">
                                <Label>Lecture Video</Label>

                                {/* Current or New Video Preview */}
                                {(videoPreview || currentVideoUrl) && (
                                    <div className="relative w-full aspect-video rounded-lg overflow-hidden border bg-muted mb-2">
                                        <video
                                            src={videoPreview || formatUrl(currentVideoUrl!)}
                                            controls
                                            className="w-full h-full object-contain"
                                        />
                                        {videoPreview && (
                                            <Button
                                                type="button"
                                                variant="destructive"
                                                size="icon"
                                                className="absolute top-2 right-2"
                                                onClick={removeNewVideo}
                                            >
                                                <X className="h-4 w-4" />
                                            </Button>
                                        )}
                                    </div>
                                )}

                                <div className="flex items-center gap-3">
                                    <Input
                                        id="video"
                                        type="file"
                                        accept="video/*"
                                        onChange={handleVideoChange}
                                        className="hidden"
                                    />
                                    <Button
                                        type="button"
                                        variant="outline"
                                        onClick={() => document.getElementById('video')?.click()}
                                        className="gap-2"
                                    >
                                        <Video className="h-4 w-4" />
                                        {currentVideoUrl || videoPreview ? 'Change Video' : 'Upload Video'}
                                    </Button>
                                    {newVideo && (
                                        <span className="text-sm text-muted-foreground">
                                            {newVideo.name}
                                        </span>
                                    )}
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="duration">Duration (minutes) *</Label>
                                    <Input
                                        id="duration"
                                        type="number"
                                        min="1"
                                        step="1"
                                        placeholder="30"
                                        value={formData.duration || ''}
                                        onChange={(e) => setFormData({ ...formData, duration: parseFloat(e.target.value) || 0 })}
                                        required
                                    />
                                </div>

                                <div className="space-y-2">
                                    <Label htmlFor="price">Price per 10 Minutes (₹) *</Label>
                                    <Input
                                        id="price"
                                        type="number"
                                        min="0"
                                        step="0.01"
                                        placeholder="10.00"
                                        value={formData.price_per_10_mins || ''}
                                        onChange={(e) => setFormData({ ...formData, price_per_10_mins: parseFloat(e.target.value) || 0 })}
                                        required
                                    />
                                </div>
                            </div>

                            <div className="flex gap-3 pt-4">
                                <Button type="submit" disabled={saving} className="flex-1">
                                    {saving ? (
                                        <>
                                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                            Saving...
                                        </>
                                    ) : (
                                        'Save Changes'
                                    )}
                                </Button>
                                <Button
                                    type="button"
                                    variant="outline"
                                    onClick={() => navigate(`/instructor/courses/${courseId}`)}
                                    disabled={saving}
                                >
                                    Cancel
                                </Button>
                            </div>
                        </form>
                    </CardContent>
                </Card>
            </section>
        </div>
    );
};

export default InstructorLectureEdit;
