import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { paymentApi, ChatbotSource } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { MessageCircle, X, Send, Bot, Mic, MicOff, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";

interface Message {
    role: 'user' | 'bot';
    content: string;
    sources?: ChatbotSource[];
}

export const ChatBot = () => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const [isOpen, setIsOpen] = useState(false);
    const [messages, setMessages] = useState<Message[]>([
        { role: 'bot', content: 'Hello! I am Murph AI, your learning assistant. Ask me anything about your courses!' }
    ]);
    const [inputValue, setInputValue] = useState("");
    const [isTyping, setIsTyping] = useState(false);
    const [showLoginPrompt, setShowLoginPrompt] = useState(false);
    const [isRecording, setIsRecording] = useState(false);
    const [sessionId] = useState(() => `session_${Date.now()}`);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioChunksRef = useRef<Blob[]>([]);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages, isOpen]);

    const toggleChat = () => {
        if (!user) {
            setShowLoginPrompt(true);
            setTimeout(() => setShowLoginPrompt(false), 3000);
            return;
        }
        setIsOpen(!isOpen);
    };

    const handleSendMessage = async () => {
        if (!inputValue.trim() || isTyping) return;

        const userMessage = inputValue;
        setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
        setInputValue("");
        setIsTyping(true);

        try {
            const response = await paymentApi.sendChatMessage(userMessage, sessionId);
            setMessages(prev => [...prev, {
                role: 'bot',
                content: response.answer,
                sources: response.sources
            }]);
        } catch (error) {
            console.error('Chatbot error:', error);
            setMessages(prev => [...prev, {
                role: 'bot',
                content: 'Sorry, I encountered an error. Please try again.'
            }]);
            toast.error('Failed to get response');
        } finally {
            setIsTyping(false);
        }
    };

    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
            mediaRecorderRef.current = mediaRecorder;
            audioChunksRef.current = [];

            mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) {
                    audioChunksRef.current.push(event.data);
                }
            };

            mediaRecorder.onstop = async () => {
                const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
                stream.getTracks().forEach(track => track.stop());

                // Send to API
                setMessages(prev => [...prev, { role: 'user', content: '🎤 Voice message' }]);
                setIsTyping(true);

                try {
                    const response = await paymentApi.sendVoiceMessage(audioBlob);
                    setMessages(prev => [...prev, {
                        role: 'bot',
                        content: response.answer,
                        sources: response.sources
                    }]);
                } catch (error) {
                    console.error('Voice chatbot error:', error);
                    setMessages(prev => [...prev, {
                        role: 'bot',
                        content: 'Sorry, I could not process your voice message. Please try again.'
                    }]);
                    toast.error('Failed to process voice message');
                } finally {
                    setIsTyping(false);
                }
            };

            mediaRecorder.start();
            setIsRecording(true);
        } catch (error) {
            console.error('Microphone error:', error);
            toast.error('Could not access microphone. Please check permissions.');
        }
    };

    const stopRecording = () => {
        if (mediaRecorderRef.current && isRecording) {
            mediaRecorderRef.current.stop();
            setIsRecording(false);
        }
    };

    const handleSourceClick = (source: ChatbotSource) => {
        navigate(`/student/lecture/${source.lecture_id}`);
        setIsOpen(false);
    };

    return (
        <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-2">
            <AnimatePresence>
                {showLoginPrompt && (
                    <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.9 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.9 }}
                        className="bg-destructive text-destructive-foreground px-4 py-2 rounded-lg shadow-lg mb-2 text-sm font-medium whitespace-nowrap"
                    >
                        Please <Link to="/login" className="underline hover:text-white">login</Link> or <Link to="/signup" className="underline hover:text-white">sign up</Link> to chat!
                    </motion.div>
                )}
            </AnimatePresence>

            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95, y: 20 }}
                        transition={{ duration: 0.2 }}
                        className="mb-4 w-[350px] sm:w-[400px]"
                    >
                        <Card className="border-primary/20 shadow-2xl overflow-hidden backdrop-blur-sm bg-background/95">
                            <CardHeader className="bg-primary/5 p-4 flex flex-row items-center justify-between border-b">
                                <div className="flex items-center gap-2">
                                    <div className="p-2 bg-primary/10 rounded-full">
                                        <Bot className="w-5 h-5 text-primary" />
                                    </div>
                                    <div>
                                        <CardTitle className="text-base">Murph AI</CardTitle>
                                        <div className="flex items-center gap-1.5">
                                            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                                            <span className="text-xs text-muted-foreground">Online</span>
                                        </div>
                                    </div>
                                </div>
                                <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-muted" onClick={() => setIsOpen(false)}>
                                    <X className="w-4 h-4" />
                                </Button>
                            </CardHeader>
                            <CardContent className="p-4 h-[350px] overflow-y-auto space-y-4">
                                {messages.map((msg, idx) => (
                                    <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                                        <div className="max-w-[85%]">
                                            <div
                                                className={`px-3 py-2 rounded-lg text-sm ${msg.role === 'user'
                                                    ? 'bg-primary text-primary-foreground rounded-tr-none'
                                                    : 'bg-muted text-foreground rounded-tl-none prose prose-sm dark:prose-invert max-w-none'
                                                    }`}
                                            >
                                                {msg.role === 'bot' ? (
                                                    <ReactMarkdown
                                                        components={{
                                                            p: ({ children }) => <p className="mb-2 last:mb-0">{children}</p>,
                                                            ul: ({ children }) => <ul className="list-disc pl-4 mb-2">{children}</ul>,
                                                            ol: ({ children }) => <ol className="list-decimal pl-4 mb-2">{children}</ol>,
                                                            li: ({ children }) => <li className="mb-1">{children}</li>,
                                                            code: ({ children }) => <code className="bg-background/50 px-1 py-0.5 rounded text-xs">{children}</code>,
                                                            pre: ({ children }) => <pre className="bg-background/50 p-2 rounded text-xs overflow-x-auto mb-2">{children}</pre>,
                                                            strong: ({ children }) => <strong className="font-semibold">{children}</strong>,
                                                            h1: ({ children }) => <h1 className="text-base font-bold mb-1">{children}</h1>,
                                                            h2: ({ children }) => <h2 className="text-sm font-bold mb-1">{children}</h2>,
                                                            h3: ({ children }) => <h3 className="text-sm font-semibold mb-1">{children}</h3>,
                                                        }}
                                                    >
                                                        {msg.content}
                                                    </ReactMarkdown>
                                                ) : (
                                                    msg.content
                                                )}
                                            </div>
                                            {/* Source links */}
                                            {msg.sources && msg.sources.length > 0 && (
                                                <div className="mt-2 space-y-1">
                                                    <p className="text-xs text-muted-foreground font-medium">Sources:</p>
                                                    {msg.sources.map((source, sIdx) => (
                                                        <button
                                                            key={sIdx}
                                                            onClick={() => handleSourceClick(source)}
                                                            className="block w-full text-left text-xs p-2 bg-primary/5 hover:bg-primary/10 rounded border border-primary/20 transition-colors"
                                                        >
                                                            <span className="font-medium text-primary">{source.lecture_title}</span>
                                                            <span className="text-muted-foreground"> • {source.course_title}</span>
                                                        </button>
                                                    ))}
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                ))}
                                {isTyping && (
                                    <div className="flex justify-start">
                                        <div className="bg-muted px-3 py-2 rounded-lg rounded-tl-none flex items-center gap-1">
                                            <span className="w-1.5 h-1.5 bg-foreground/40 rounded-full animate-bounce [animation-delay:-0.3s]" />
                                            <span className="w-1.5 h-1.5 bg-foreground/40 rounded-full animate-bounce [animation-delay:-0.15s]" />
                                            <span className="w-1.5 h-1.5 bg-foreground/40 rounded-full animate-bounce" />
                                        </div>
                                    </div>
                                )}
                                <div ref={messagesEndRef} />
                            </CardContent>
                            <CardFooter className="p-3 bg-muted/20 border-t">
                                <form
                                    className="flex w-full gap-2"
                                    onSubmit={(e) => {
                                        e.preventDefault();
                                        handleSendMessage();
                                    }}
                                >
                                    <Input
                                        placeholder="Type a message..."
                                        value={inputValue}
                                        onChange={(e) => setInputValue(e.target.value)}
                                        className="h-9 focus-visible:ring-1"
                                        disabled={isTyping || isRecording}
                                    />
                                    <Button
                                        type="button"
                                        size="icon"
                                        variant={isRecording ? "destructive" : "outline"}
                                        className="h-9 w-9 shrink-0"
                                        onClick={isRecording ? stopRecording : startRecording}
                                        disabled={isTyping}
                                    >
                                        {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                                    </Button>
                                    <Button type="submit" size="icon" className="h-9 w-9 shrink-0" disabled={!inputValue.trim() || isTyping}>
                                        {isTyping ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                                    </Button>
                                </form>
                            </CardFooter>
                        </Card>
                    </motion.div>
                )}
            </AnimatePresence>

            <Button
                onClick={toggleChat}
                size="lg"
                className="rounded-full w-14 h-14 shadow-lg hover:shadow-xl hover:scale-105 transition-all p-0 bg-primary hover:bg-primary/90"
            >
                {isOpen ? (
                    <X className="w-6 h-6" />
                ) : (
                    <MessageCircle className="w-7 h-7" />
                )}
            </Button>
        </div>
    );
};
