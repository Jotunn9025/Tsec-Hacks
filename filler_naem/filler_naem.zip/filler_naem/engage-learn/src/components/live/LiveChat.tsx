import { useState, useEffect, useRef } from 'react';
import { ChatMessage } from '@/lib/api';
import { useLiveChat } from '@/hooks/useLiveChat';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Send, Wifi, WifiOff } from 'lucide-react';
import { format } from 'date-fns';

interface LiveChatProps {
    sessionId: number;
    userId: number;
    username: string;
    isInstructor?: boolean;
    instructorId?: number;
}

export function LiveChat({
    sessionId,
    userId,
    username,
    isInstructor,
    instructorId,
}: LiveChatProps) {
    const [inputValue, setInputValue] = useState('');
    const scrollRef = useRef<HTMLDivElement>(null);
    const { messages, sendMessage, isConnected, error } = useLiveChat({
        sessionId,
        userId,
        username,
    });

    // Auto-scroll to bottom when new messages arrive
    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [messages]);

    const handleSend = () => {
        if (!inputValue.trim()) return;
        sendMessage(inputValue.trim());
        setInputValue('');
    };

    const handleKeyPress = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };

    const getInitials = (name: string) => {
        return name
            .split(' ')
            .map((n) => n[0])
            .join('')
            .toUpperCase()
            .slice(0, 2);
    };

    return (
        <div className="flex flex-col h-full border rounded-lg bg-background">
            {/* Header */}
            <div className="flex items-center justify-between p-3 border-b bg-muted/50">
                <h3 className="font-semibold">Live Chat</h3>
                <div className="flex items-center gap-2 text-sm">
                    {isConnected ? (
                        <span className="flex items-center gap-1 text-green-600">
                            <Wifi className="h-4 w-4" />
                            Connected
                        </span>
                    ) : (
                        <span className="flex items-center gap-1 text-red-500">
                            <WifiOff className="h-4 w-4" />
                            Disconnected
                        </span>
                    )}
                </div>
            </div>

            {/* Messages */}
            <ScrollArea className="flex-1 p-3" ref={scrollRef}>
                <div className="space-y-3">
                    {messages.length === 0 && (
                        <p className="text-center text-sm text-muted-foreground py-8">
                            No messages yet. Say hello! 👋
                        </p>
                    )}
                    {messages.map((msg, index) => {
                        const isOwn = msg.user_id === userId;
                        const isMsgFromInstructor = msg.user_id === instructorId;

                        return (
                            <div
                                key={index}
                                className={`flex gap-2 ${isOwn ? 'flex-row-reverse' : 'flex-row'}`}
                            >
                                <Avatar className="h-8 w-8 flex-shrink-0">
                                    <AvatarFallback className={isMsgFromInstructor ? 'bg-primary text-primary-foreground' : ''}>
                                        {getInitials(msg.username)}
                                    </AvatarFallback>
                                </Avatar>
                                <div className={`max-w-[70%] ${isOwn ? 'text-right' : 'text-left'}`}>
                                    <div className="flex items-center gap-2 mb-1">
                                        <span className="text-xs font-medium">
                                            {isOwn ? 'You' : msg.username}
                                        </span>
                                        {isMsgFromInstructor && !isOwn && (
                                            <Badge variant="secondary" className="text-xs py-0">
                                                Instructor
                                            </Badge>
                                        )}
                                        <span className="text-xs text-muted-foreground">
                                            {format(new Date(msg.timestamp), 'h:mm a')}
                                        </span>
                                    </div>
                                    <div
                                        className={`inline-block px-3 py-2 rounded-lg text-sm ${isOwn
                                                ? 'bg-primary text-primary-foreground'
                                                : 'bg-muted'
                                            }`}
                                    >
                                        {msg.message}
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </ScrollArea>

            {/* Input */}
            <div className="flex gap-2 p-3 border-t">
                <Input
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Type a message..."
                    disabled={!isConnected}
                    className="flex-1"
                />
                <Button
                    onClick={handleSend}
                    disabled={!isConnected || !inputValue.trim()}
                    size="icon"
                >
                    <Send className="h-4 w-4" />
                </Button>
            </div>
        </div>
    );
}
