import { LiveSession } from '@/lib/api';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';
import { Users, Clock, IndianRupee, Radio, Calendar, User } from 'lucide-react';

interface LiveSessionCardProps {
    session: LiveSession;
    onRegister?: () => void;
    onJoin?: () => void;
    onView?: () => void;
    isRegistered?: boolean;
    isInstructor?: boolean;
    onStart?: () => void;
    onEnd?: () => void;
    onManage?: () => void;
}

export function LiveSessionCard({
    session,
    onRegister,
    onJoin,
    onView,
    isRegistered,
    isInstructor,
    onStart,
    onEnd,
    onManage,
}: LiveSessionCardProps) {
    const getStatusBadge = () => {
        switch (session.status) {
            case 'live':
                return (
                    <Badge className="bg-red-500 animate-pulse flex items-center gap-1">
                        <Radio className="h-3 w-3" />
                        LIVE
                    </Badge>
                );
            case 'scheduled':
                return <Badge variant="secondary">Scheduled</Badge>;
            case 'ended':
                return <Badge variant="outline">Ended</Badge>;
            case 'cancelled':
                return <Badge variant="destructive">Cancelled</Badge>;
            default:
                return null;
        }
    };

    const formatDateTime = (dateStr: string) => {
        return format(new Date(dateStr), 'MMM d, yyyy • h:mm a');
    };

    return (
        <Card className="overflow-hidden hover:shadow-lg transition-shadow">
            {session.thumbnail_url && (
                <div className="relative h-40 bg-muted">
                    <img
                        src={session.thumbnail_url}
                        alt={session.title}
                        className="w-full h-full object-cover"
                    />
                    <div className="absolute top-2 right-2">{getStatusBadge()}</div>
                </div>
            )}
            {!session.thumbnail_url && (
                <div className="relative h-40 bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                    <Radio className="h-12 w-12 text-primary/30" />
                    <div className="absolute top-2 right-2">{getStatusBadge()}</div>
                </div>
            )}

            <CardHeader className="pb-2">
                <div className="flex items-start justify-between gap-2">
                    <h3 className="font-semibold text-lg line-clamp-2">{session.title}</h3>
                </div>
                {session.instructor_name && (
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <User className="h-3 w-3" />
                        {session.instructor_name}
                    </div>
                )}
            </CardHeader>

            <CardContent className="space-y-3">
                {session.description && (
                    <p className="text-sm text-muted-foreground line-clamp-2">
                        {session.description}
                    </p>
                )}

                <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                        <Calendar className="h-4 w-4" />
                        <span>{formatDateTime(session.scheduled_start)}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                        <Clock className="h-4 w-4" />
                        <span>
                            {Math.round(
                                (new Date(session.scheduled_end).getTime() -
                                    new Date(session.scheduled_start).getTime()) /
                                60000
                            )}{' '}
                            min
                        </span>
                    </div>
                    <div className="flex items-center gap-1.5">
                        <IndianRupee className="h-4 w-4 text-green-600" />
                        <span className="font-medium text-green-600">₹{session.price}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                        <Users className="h-4 w-4" />
                        <span>
                            {session.current_participants || 0}
                            {session.max_participants && ` / ${session.max_participants}`}
                        </span>
                    </div>
                </div>

                {session.category && (
                    <Badge variant="outline" className="mt-2">
                        {session.category}
                    </Badge>
                )}
            </CardContent>

            <CardFooter className="flex gap-2">
                {isInstructor ? (
                    <>
                        {session.status === 'scheduled' && (
                            <Button onClick={onStart} className="flex-1 bg-red-500 hover:bg-red-600">
                                <Radio className="h-4 w-4 mr-2" />
                                Go Live
                            </Button>
                        )}
                        {session.status === 'live' && (
                            <>
                                <Button onClick={onManage} variant="outline" className="flex-1">
                                    Manage
                                </Button>
                                <Button onClick={onEnd} variant="destructive" className="flex-1">
                                    End Session
                                </Button>
                            </>
                        )}
                        {session.status === 'ended' && (
                            <Button onClick={onView} variant="outline" className="flex-1">
                                View Stats
                            </Button>
                        )}
                    </>
                ) : (
                    <>
                        {session.status === 'scheduled' && !isRegistered && (
                            <Button onClick={onRegister} className="flex-1">
                                Register - ₹{session.price}
                            </Button>
                        )}
                        {session.status === 'scheduled' && isRegistered && (
                            <Button variant="outline" className="flex-1" disabled>
                                ✓ Registered
                            </Button>
                        )}
                        {session.status === 'live' && (
                            <Button onClick={onJoin} className="flex-1 bg-red-500 hover:bg-red-600">
                                <Radio className="h-4 w-4 mr-2" />
                                Join Live
                            </Button>
                        )}
                        {session.status === 'ended' && (
                            <Button variant="outline" className="flex-1" disabled>
                                Session Ended
                            </Button>
                        )}
                    </>
                )}
            </CardFooter>
        </Card>
    );
}
