import { useState, useEffect, useCallback, useRef } from 'react';
import { ChatMessage } from '@/lib/api';

interface UseLiveChatProps {
    sessionId: number;
    userId: number;
    username: string;
    wsBaseUrl?: string;
}

interface UseLiveChatReturn {
    messages: ChatMessage[];
    sendMessage: (text: string) => void;
    isConnected: boolean;
    error: Error | null;
}

const WS_BASE_URL = 'ws://localhost:8000';

export function useLiveChat({
    sessionId,
    userId,
    username,
    wsBaseUrl = WS_BASE_URL,
}: UseLiveChatProps): UseLiveChatReturn {
    const wsRef = useRef<WebSocket | null>(null);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [isConnected, setIsConnected] = useState(false);
    const [error, setError] = useState<Error | null>(null);

    useEffect(() => {
        const connect = () => {
            try {
                const ws = new WebSocket(`${wsBaseUrl}/live/ws/chat/${sessionId}`);
                wsRef.current = ws;

                ws.onopen = () => {
                    console.log('[Chat] Connected to WebSocket');
                    setIsConnected(true);
                    setError(null);
                };

                ws.onmessage = (event) => {
                    try {
                        const message: ChatMessage = JSON.parse(event.data);
                        setMessages((prev) => [...prev, message]);
                    } catch (err) {
                        console.error('[Chat] Failed to parse message:', err);
                    }
                };

                ws.onerror = (event) => {
                    console.error('[Chat] WebSocket error:', event);
                    setError(new Error('WebSocket connection error'));
                };

                ws.onclose = (event) => {
                    console.log('[Chat] WebSocket closed:', event.code, event.reason);
                    setIsConnected(false);

                    // Attempt reconnect after 3 seconds if not intentional close
                    if (event.code !== 1000) {
                        setTimeout(connect, 3000);
                    }
                };
            } catch (err) {
                console.error('[Chat] Failed to connect:', err);
                setError(err as Error);
            }
        };

        connect();

        return () => {
            if (wsRef.current) {
                wsRef.current.close(1000, 'Component unmounted');
            }
        };
    }, [sessionId, wsBaseUrl]);

    const sendMessage = useCallback(
        (text: string) => {
            if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
                console.error('[Chat] Cannot send message: WebSocket not connected');
                return;
            }

            const message: ChatMessage = {
                user_id: userId,
                username: username,
                message: text,
                timestamp: new Date().toISOString(),
            };

            // Add message locally (backend excludes sender from broadcast)
            setMessages((prev) => [...prev, message]);

            // Send to WebSocket
            wsRef.current.send(JSON.stringify(message));
        },
        [userId, username]
    );

    return {
        messages,
        sendMessage,
        isConnected,
        error,
    };
}
