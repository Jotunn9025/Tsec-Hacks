import { useState, useEffect, useCallback, useRef } from 'react';
import AgoraRTC, {
    IAgoraRTCClient,
    IAgoraRTCRemoteUser,
    ILocalVideoTrack,
    ILocalAudioTrack,
    ICameraVideoTrack,
    IMicrophoneAudioTrack,
} from 'agora-rtc-sdk-ng';

interface UseAgoraRTCProps {
    appId: string;
    channel: string;
    token: string;
    uid: number;
    role: 'publisher' | 'subscriber';
    enabled?: boolean; // New: Only connect when enabled is true
}

interface UseAgoraRTCReturn {
    localVideoTrack: ICameraVideoTrack | null;
    localAudioTrack: IMicrophoneAudioTrack | null;
    remoteUsers: IAgoraRTCRemoteUser[];
    isConnected: boolean;
    isPublishing: boolean;
    isMuted: boolean;
    isVideoOff: boolean;
    error: Error | null;
    startPublishing: () => Promise<void>;
    stopPublishing: () => Promise<void>;
    toggleMute: () => void;
    toggleVideo: () => void;
    leave: () => Promise<void>;
}

export function useAgoraRTC({
    appId,
    channel,
    token,
    uid,
    role,
    enabled = true, // Default to true for backward compatibility
}: UseAgoraRTCProps): UseAgoraRTCReturn {
    const clientRef = useRef<IAgoraRTCClient | null>(null);
    const [localVideoTrack, setLocalVideoTrack] = useState<ICameraVideoTrack | null>(null);
    const [localAudioTrack, setLocalAudioTrack] = useState<IMicrophoneAudioTrack | null>(null);
    const [remoteUsers, setRemoteUsers] = useState<IAgoraRTCRemoteUser[]>([]);
    const [isConnected, setIsConnected] = useState(false);
    const [isPublishing, setIsPublishing] = useState(false);
    const [isMuted, setIsMuted] = useState(false);
    const [isVideoOff, setIsVideoOff] = useState(false);
    const [error, setError] = useState<Error | null>(null);

    // Initialize client - only when enabled
    useEffect(() => {
        // Skip if not enabled or missing required params
        if (!enabled || !appId || !channel || !token) {
            return;
        }

        const client = AgoraRTC.createClient({ mode: 'rtc', codec: 'vp8' });
        clientRef.current = client;

        const handleUserPublished = async (user: IAgoraRTCRemoteUser, mediaType: 'audio' | 'video') => {
            await client.subscribe(user, mediaType);
            setRemoteUsers((prev) => {
                const exists = prev.find((u) => u.uid === user.uid);
                if (exists) {
                    return prev.map((u) => (u.uid === user.uid ? user : u));
                }
                return [...prev, user];
            });
        };

        const handleUserUnpublished = (user: IAgoraRTCRemoteUser) => {
            setRemoteUsers((prev) => prev.filter((u) => u.uid !== user.uid));
        };

        const handleUserLeft = (user: IAgoraRTCRemoteUser) => {
            setRemoteUsers((prev) => prev.filter((u) => u.uid !== user.uid));
        };

        client.on('user-published', handleUserPublished);
        client.on('user-unpublished', handleUserUnpublished);
        client.on('user-left', handleUserLeft);

        // Join channel
        const join = async () => {
            try {
                await client.join(appId, channel, token, uid);
                setIsConnected(true);

                // Auto-publish for publishers (instructors)
                if (role === 'publisher') {
                    const [audioTrack, videoTrack] = await AgoraRTC.createMicrophoneAndCameraTracks();
                    setLocalAudioTrack(audioTrack);
                    setLocalVideoTrack(videoTrack);
                    await client.publish([audioTrack, videoTrack]);
                    setIsPublishing(true);
                }
            } catch (err) {
                console.error('Failed to join Agora channel:', err);
                setError(err as Error);
            }
        };

        join();

        return () => {
            client.off('user-published', handleUserPublished);
            client.off('user-unpublished', handleUserUnpublished);
            client.off('user-left', handleUserLeft);

            localAudioTrack?.close();
            localVideoTrack?.close();
            client.leave();
        };
    }, [appId, channel, token, uid, role, enabled]);

    const startPublishing = useCallback(async () => {
        if (!clientRef.current || isPublishing) return;
        try {
            const [audioTrack, videoTrack] = await AgoraRTC.createMicrophoneAndCameraTracks();
            setLocalAudioTrack(audioTrack);
            setLocalVideoTrack(videoTrack);
            await clientRef.current.publish([audioTrack, videoTrack]);
            setIsPublishing(true);
        } catch (err) {
            setError(err as Error);
        }
    }, [isPublishing]);

    const stopPublishing = useCallback(async () => {
        if (!clientRef.current || !isPublishing) return;
        try {
            if (localAudioTrack) {
                await clientRef.current.unpublish(localAudioTrack);
                localAudioTrack.close();
                setLocalAudioTrack(null);
            }
            if (localVideoTrack) {
                await clientRef.current.unpublish(localVideoTrack);
                localVideoTrack.close();
                setLocalVideoTrack(null);
            }
            setIsPublishing(false);
        } catch (err) {
            setError(err as Error);
        }
    }, [isPublishing, localAudioTrack, localVideoTrack]);

    const toggleMute = useCallback(() => {
        if (localAudioTrack) {
            localAudioTrack.setEnabled(isMuted);
            setIsMuted(!isMuted);
        }
    }, [localAudioTrack, isMuted]);

    const toggleVideo = useCallback(() => {
        if (localVideoTrack) {
            localVideoTrack.setEnabled(isVideoOff);
            setIsVideoOff(!isVideoOff);
        }
    }, [localVideoTrack, isVideoOff]);

    const leave = useCallback(async () => {
        if (localAudioTrack) {
            localAudioTrack.close();
            setLocalAudioTrack(null);
        }
        if (localVideoTrack) {
            localVideoTrack.close();
            setLocalVideoTrack(null);
        }
        if (clientRef.current) {
            await clientRef.current.leave();
            setIsConnected(false);
            setIsPublishing(false);
        }
    }, [localAudioTrack, localVideoTrack]);

    return {
        localVideoTrack,
        localAudioTrack,
        remoteUsers,
        isConnected,
        isPublishing,
        isMuted,
        isVideoOff,
        error,
        startPublishing,
        stopPublishing,
        toggleMute,
        toggleVideo,
        leave,
    };
}
